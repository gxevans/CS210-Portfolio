#ifndef GROCERYTRACKING_H
#define GROCERYTRACKING_H
#include <string>
#include <map>
using namespace std;

class GroceryTracking {
private:
    map<string, int> itemFrequency;

public:
    void LoadData(string fileName);
    void CreateBackupFile(string fileName);
    int GetItemFrequency(string item);
    void PrintAllFrequencies();
    void PrintHistogram();
};

#endif