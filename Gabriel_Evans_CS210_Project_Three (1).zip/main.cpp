#include <iostream>
#include <limits>
#include "GroceryTracking.h"
using namespace std;

void DisplayMenu() {
    cout << "\n===== Corner Grocer Menu =====\n";
    cout << "1. Search for an item frequency\n";
    cout << "2. Display all item frequencies\n";
    cout << "3. Display histogram\n";
    cout << "4. Exit\n";
    cout << "Enter your choice: ";
}

int main() {
    GroceryTracking grocery;
    grocery.LoadData("CS210_Project_Three_Input_File.txt");
    grocery.CreateBackupFile("frequency.dat");

    int choice = 0;

    while (choice != 4) {
        DisplayMenu();

        while (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number between 1 and 4: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        switch (choice) {
        case 1: {
            string item;
            cout << "Enter item name: ";
            cin >> item;
            cout << item << " was purchased " << grocery.GetItemFrequency(item) << " time(s)." << endl;
            break;
        }
        case 2:
            grocery.PrintAllFrequencies();
            break;
        case 3:
            grocery.PrintHistogram();
            break;
        case 4:
            cout << "Program terminated." << endl;
            break;
        default:
            cout << "Please select a valid menu option." << endl;
        }
    }
    return 0;
}