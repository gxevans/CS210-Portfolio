#include "GroceryTracking.h"
#include <iostream>
#include <fstream>
using namespace std;

void GroceryTracking::LoadData(string fileName) {
    ifstream inFS(fileName);
    string item;
    while (inFS >> item) {
        itemFrequency[item]++;
    }
    inFS.close();
}

void GroceryTracking::CreateBackupFile(string fileName) {
    ofstream outFS(fileName);
    for (auto item : itemFrequency) {
        outFS << item.first << " " << item.second << endl;
    }
    outFS.close();
}

int GroceryTracking::GetItemFrequency(string item) {
    if (itemFrequency.find(item) != itemFrequency.end()) {
        return itemFrequency[item];
    }
    return 0;
}

void GroceryTracking::PrintAllFrequencies() {
    for (auto item : itemFrequency) {
        cout << item.first << " " << item.second << endl;
    }
}

void GroceryTracking::PrintHistogram() {
    for (auto item : itemFrequency) {
        cout << item.first << " ";
        for (int i = 0; i < item.second; i++) {
            cout << "*";
        }
        cout << endl;
    }
}