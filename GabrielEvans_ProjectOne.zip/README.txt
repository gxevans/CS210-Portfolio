Gabriel Evans
Chada Tech Clocks Project

Files Included:
- main.cpp
- Clock.cpp
- Clock.h

Description:
This program displays both a 12-hour and 24-hour clock simultaneously.
The user can increment the hour, minute, or second using a menu system.

Features:
- Modularized design using classes
- Proper formatting using setw and setfill
- Input validation through menu selection
- Readable and maintainable code
