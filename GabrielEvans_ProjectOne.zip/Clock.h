/*
 * Name: Gabriel Evans
 * Project: Chada Tech Clocks
 * Description: Header file for Clock class
 */

#ifndef CLOCK_H
#define CLOCK_H

class Clock {
private:
    int hours;
    int minutes;
    int seconds;

public:
    // Constructor
    Clock();

    // Time modification functions
    void AddHour();
    void AddMinute();
    void AddSecond();

    // Display functions
    void DisplayClocks();

    // Menu function
    void DisplayMenu();

private:
    // Helper functions
    void Display12Hour();
    void Display24Hour();
};

#endif
