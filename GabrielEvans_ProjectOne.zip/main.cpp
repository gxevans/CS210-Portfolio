/*
 * Name: Gabriel Evans
 * Project: Chada Tech Clocks
 * Description: Main driver file for clock application
 */

#include <iostream>
#include "Clock.h"

using namespace std;

int main() {
    Clock myClock;

    int userChoice = 0;

    // Main program loop
    while (userChoice != 4) {

        // Display clocks and menu
        myClock.DisplayClocks();
        myClock.DisplayMenu();

        cout << "Enter your choice: ";
        cin >> userChoice;

        // Process user input
        switch (userChoice) {

        case 1:
            myClock.AddHour();
            break;

        case 2:
            myClock.AddMinute();
            break;

        case 3:
            myClock.AddSecond();
            break;

        case 4:
            cout << "Exiting program..." << endl;
            break;

        default:
            cout << "Invalid option. Please try again." << endl;
        }

        cout << endl;
    }

    return 0;
}
