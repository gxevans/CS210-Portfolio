/*
 * Name: Gabriel Evans
 * Project: Chada Tech Clocks
 * Description: Implementation file for Clock class
 */

#include <iostream>
#include <iomanip>
#include "Clock.h"

using namespace std;

// Constructor initializes time to 00:00:00
Clock::Clock() {
    hours = 0;
    minutes = 0;
    seconds = 0;
}

// Adds one hour to the clock
void Clock::AddHour() {
    hours = (hours + 1) % 24;
}

// Adds one minute to the clock
void Clock::AddMinute() {
    minutes++;

    if (minutes >= 60) {
        minutes = 0;
        AddHour();
    }
}

// Adds one second to the clock
void Clock::AddSecond() {
    seconds++;

    if (seconds >= 60) {
        seconds = 0;
        AddMinute();
    }
}

// Displays both clocks side by side
void Clock::DisplayClocks() {
    cout << "**************************     **************************" << endl;
    cout << "*     12-Hour Clock     *     *     24-Hour Clock     *" << endl;

    cout << "*     ";
    Display12Hour();

    cout << "     *     *        ";
    Display24Hour();

    cout << "        *" << endl;
    cout << "**************************     **************************" << endl;
}

// Displays time in 12-hour format
void Clock::Display12Hour() {
    int displayHour = hours;
    string period = "AM";

    if (hours == 0) {
        displayHour = 12;
    }
    else if (hours >= 12) {
        period = "PM";

        if (hours > 12) {
            displayHour = hours - 12;
        }
    }

    cout << setfill('0') << setw(2) << displayHour << ":"
         << setw(2) << minutes << ":"
         << setw(2) << seconds << " "
         << period;
}

// Displays time in 24-hour format
void Clock::Display24Hour() {
    cout << setfill('0') << setw(2) << hours << ":"
         << setw(2) << minutes << ":"
         << setw(2) << seconds;
}

// Displays menu options
void Clock::DisplayMenu() {
    cout << endl;
    cout << "**********************" << endl;
    cout << "* 1 - Add One Hour   *" << endl;
    cout << "* 2 - Add One Minute *" << endl;
    cout << "* 3 - Add One Second *" << endl;
    cout << "* 4 - Exit Program   *" << endl;
    cout << "**********************" << endl;
}
